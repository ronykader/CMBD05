<?php 
//  database connection
    $servarname = 'localhost';
    $username   = 'root';
    $password   = '';
    $database   = 'cmbd_05';

    $db = new mysqli($servarname,$username,$password,$database);

    if( $db->connect_error ) {
        die($db->connect_error);
    }

    