<?php 
  include('db.php');
    if( isset($_POST['user_submit']) == 'Register' ) {

        $fullName       = $_POST['full_name'];
        $eamilAddress   = $_POST['email_address'];
        $userName       = $_POST['user_name'];
        $phoneNumber    = $_POST['phone_number'];

      if( !empty($fullName) && !empty($eamilAddress) && !empty($userName) && !empty($phoneNumber)) {
        
        $sql = "INSERT INTO cmbd_users (full_name,email_address,user_name,phone_number) 
              VALUES('$fullName','$eamilAddress','$userName','$phoneNumber')";     

          $InsertData = $db->query($sql);
          if( $InsertData === TRUE ) {
            $FlsMsg = "DATA INSERT SUCCESSFULLY";
          } else{
            $FlsMsg = "PLEASE TRY AGAIN LATER";
          }
          

        }else {
            $FlsMsg = "Mail send hobe na";
        }
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel</title>

    <!-- icon on tab integration -->
    <link rel="icon" href="" type="image/x-icon">

    <!-- Bootstrap integration -->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">


    <!-- Boiler integration -->
    <link rel="stylesheet" href="text/css" href="css/normalize.css">
    <link rel="stylesheet" href="text/css" href="css/main.css">
    <script src="js/modernizr-3.6.0.min.js"></script>

<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="css/style.css">


</head>

<body>

  <!-- body starts -->

<!-- navbar starts -->

<nav class="navbar navbar-default header-area">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#">Laravel</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#">Log In</a></li>
        <li><a href="#">Register</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container -->
</nav>

<!-- navbar ends -->

<!-- form starts -->


<div class="container form-area">
    <div class="row margin">
        <div class="col-md-2 col-sm-2"></div>

        <div class="col-md-8 col-sm-8 col-xs-12">
            <div class="panel panel-default">
                <div class="panel-heading form-heading"> Register <span style="color:red;"><?php echo $FlsMsg ?? "" ?></span></div>
                   
                    <div class="panel-body">
                     <form class="form-horizontal" action="" method="POST">
                          <div class="form-group">
                            <label for="Full Name" class="col-sm-4 control-label">Full Name</label>
                            <div class="col-sm-6">
                              <input type="text" name="full_name" class="form-control" id="full-name" placeholder="">
                            </div>
                          </div>
                          <div class="form-group">
                            <label for="E-Mail Address" class="col-sm-4 control-label">E-Mail Address</label>
                            <div class="col-sm-6">
                              <input type="email" name="email_address" class="form-control" id="email-address" placeholder="">
                            </div>
                          </div>
                          
                          <div class="form-group">
                         
                            <label for="User Name" class="col-sm-4 control-label">User Name</label>
                            <div class="col-sm-6">
                              <input type="text" name="user_name" class="form-control" id="user-name" placeholder="">
                            </div>
                             
                          </div>

                          <div class="form-group">
                            <label for="Phone Number" class="col-sm-4 control-label">Phone Number</label>
                            <div class="col-sm-6">
                              <input type="text" name="phone_number" class="form-control" placeholder="">
                            </div>
                          </div>
						  
                          <div class="form-group">
                            <div class="col-sm-offset-4 col-sm-10">
							  <!-- <button type="submit" name="" class="btn btn-primary mybtn">Register</button> -->
                				<input type="submit" name="user_submit" class="btn btn-primary mybtn" value="Register">
                
                            </div>
						  </div>
						  
                        </form>
               
            </div>
			<div class="clearfix"></div>
			
				<table class="table">

					<tr>
						<th>Full Name</th>
						<th>Phone Number</th>
					</tr>

					
					
					<?php 
						$query = "SELECT * FROM cmbd_users";
						$result = $db->query($query);
						// echo $result->num_rows;
						if( $result->num_rows > 0 ) {
							
							while ($data = $result->fetch_assoc()) { ?>
								<tr>
									<td><?php echo $data['full_name'];?></td>
									<td><?php echo $data['phone_number'];?></td>
								</tr>
							<?php }
						} else {
							echo "No Data Found";
						}
						
					
					?>


				</table>
        </div>

    </div>
    	<div class="col-md-2 col-sm-2"></div>
</div>

<!-- form ends -->
<!--    body ends-->




    <!--    Bootstrap integrtaion for js file-->
    <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>


    <!--    html5 boilerplate integration for js-->
    <script src="js/plugins.js"></script>
	<script src="js/main.js"></script>
	

	<script>
		function checkEmtyData() {

			 
			var fullname 		  = document.getElementById('full-name').value;
			var emailAddress 	= document.getElementById('email-address').value;
      var username 		  = document.getElementById('user-name').value;
      

			if (fullname == '' ) {
				alert('Full name Empty');
				return false;
			} else if( emailAddress == '' ) {
				alert('Email address is emapty');
				return false;
			} else if ( username == '' ) {
				alert('Username is Empty');
				return false;
			}

			
		}
	</script>
</body>

</html>
