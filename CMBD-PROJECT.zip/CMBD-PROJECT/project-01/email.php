<?php

if( isset($_POST['testValue']) == 'SignUp'  ) {
    $email =  $_POST['Email'];
    $subject =  $_POST['subject'];

    

    if( !empty($email) ) {

        $to         = $email;
        $subject    = $subject;
        $message    = 'lorem loremloremloremloremloremloremloremloremlorem';
        $from       = 'From: rony@gmail.com';

        $SendEmail = mail($to, $subject, $message, $from);
        if ( $SendEmail ) {
            $FlsMsg = "Email sent successfully";
        } else {
            $FlsMsg = "Please try again";
        }

    } else {
        echo "Email Not Working";
    }
}


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Page Title</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
    <?php
        if( isset($FlsMsg) ) {

            echo $FlsMsg; 
            
        }
        ?>
    <form action="" method="POST">

        <input type="text" name="subject" id="" value="" placeholder="Subject">
        <input type="email" name="Email" id="" value="" placeholder="Email">
        <input type="submit" name="testValue" value="SignUp">
    </form>
<!--End mc_embed_signup-->
</body>
</html>