<!DOCTYPE html> 
<html>
	
<head>
		<title>CODEMANBD 05</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/demo.css">
		<link rel="stylesheet" href="css/sky-forms.css">

		<!--[if lt IE 9]>
			<link rel="stylesheet" href="css/sky-forms-ie8.css">
		<![endif]-->

		<!--[if lt IE 10]>
			<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
			<script src="js/jquery.placeholder.min.js"></script>
		<![endif]-->		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/sky-forms-ie8.js"></script>
		<![endif]-->

	</head>
	<body class="bg-cyan">
		<div class="body body-s" style="background: #fff; max-width: 960px !important; margin-top: 100px;">

			<table class="table">
			  <thead class="thead-dark">
			    <tr>
			      <th scope="col">SL</th>
			      <th scope="col">Username</th>
			      <th scope="col">Email Address</th>
			      <th scope="col">Gender</th>
			      <th scope="col">Action</th>
			    </tr>
			  </thead>
			  <tbody>
			    <tr>
			      <th scope="row">1</th>
			      <td>Rony Kader</td>
			      <td>rony.ksr06@gmail.com</td>
			      <td>Male</td>
			      <td>Edit | Delete</td>
			    </tr>
			    <tr>
			      <th scope="row">2</th>
			      <td>Rony Kader</td>
			      <td>rony.ksr06@gmail.com</td>
			      <td>Male</td>
			      <td>Edit | Delete</td>
			    </tr>
			    <tr>
			      <th scope="row">3</th>
			      <td>Rony Kader</td>
			      <td>rony.ksr06@gmail.com</td>
			      <td>Male</td>
			      <td>Edit | Delete</td>
			    </tr>
			    <tr>
			      <th scope="row">4</th>
			      <td>Rony Kader</td>
			      <td>rony.ksr06@gmail.com</td>
			      <td>Male</td>
			      <td>Edit | Delete</td>
			    </tr>
			    
			  </tbody>
			</table>		
		</div>
	</body>

</html>