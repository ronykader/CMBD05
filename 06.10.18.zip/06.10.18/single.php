<!DOCTYPE html> 
<html>
	
<head>
		<title>CODEMANBD 05</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
		
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/demo.css">
		<link rel="stylesheet" href="css/sky-forms.css">

		<!--[if lt IE 9]>
			<link rel="stylesheet" href="css/sky-forms-ie8.css">
		<![endif]-->

		<!--[if lt IE 10]>
			<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
			<script src="js/jquery.placeholder.min.js"></script>
		<![endif]-->		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/sky-forms-ie8.js"></script>
		<![endif]-->

	</head>
	<body class="bg-cyan">
		<div class="body body-s" style="background: #fff; max-width: 960px !important; margin-top: 100px;">
			<img src="https://avatars0.githubusercontent.com/u/8412614?s=460&v=4" alt="" width="150" style="border-radius: 100%;">
			<br>
			<br>
			
			<table class="table">
			  <thead class="thead-dark">
			    <tr>
			      <th scope="col" colspan="5"><h3>Md.Tarikul Islam</h3></th>
			    </tr>
			  </thead>
			  <tbody>
			    <tr>
			      <td><b>First Name :</b> Rony</td>
			      <td colspan="4"><b>Last Name :</b> Kader</td>
			    </tr>

			    <tr>
			      <td><b>Mobile Number :</b> 01911873186</td>
			      <td colspan="4"><b>NID :</b> 123456</td>			    	
			    </tr>

			    <tr>
			      <td><b>E-mail Address :</b> rony.ksr06@gmail.com</td>
			      <td colspan="4"><b>Gender :</b> Male</td>			    	
			    </tr>
			    
			  </tbody>
			</table>		
		</div>
	</body>

</html>