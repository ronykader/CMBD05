<?php 
	$host 		= 'localhost';
	$user 		= 'root';
	$password 	= '';
	$database 	= 'cmbd_05';

	$db = new mysqli($host,$user,$password,$database);

	if ( $db->connect_error ) {
		die( $db->connect_error );
	}


	$username 			= 	$_POST['username'] ?? '';
	$email 				= 	$_POST['email'] ?? '';
	$mobile 			= 	$_POST['mobile'] ?? '';
	$nid 				= 	$_POST['nid'] ?? '';
	$first_name 		= 	$_POST['first_name'] ?? '';
	$last_name 			= 	$_POST['last_name'] ?? '';
	$gender 			= 	$_POST['gender'] ?? '';
	$image_name 		= 	$_FILES['photo']['name'] ?? '';

	$registration_form 	= 	$_POST['registration_form'] ?? '';

    if ( $registration_form == 'Submit') {
    	

    	if ( empty( $username )) {

    		$error = 'Please enter your username';
    		
    	} else if( empty( $email ) ) {

    		$error = 'Please enter your email address';

    	} else if ( !filter_var( $email, FILTER_VALIDATE_EMAIL ) ) {

    		$error = 'Please enter your valid email address';

    	} else if ( empty( $nid  )) {

    		$error = 'Please enter your national Id';
    		
    	} else if ( empty( $first_name ) ) {

    		$error['first_name'] = 'Please enter your first name';
    	} else if ( empty( $last_name ) ) {

    		$error = 'Please enter your last name';

    	} else if ( empty( $gender ) ) {

    		$error = 'Please select your gender';
    	} else if ( empty( $image_name ) ) {

    		$error = 'Please select your profile picture';

    	} else {

    		$image_name 	= $_FILES['photo']['name'];
    		$image_tmp_name = $_FILES['photo']['tmp_name'];
    		$image_type		= $_FILES['photo']['type'];
    		$image_size		= $_FILES['photo']['size'];
    		
    		$unique_image = time().$image_name;

    		$dir = 'image_name/';
    		$photo = $dir.$unique_image;
    		// $allow_fileType = ['jpg','jpeg','png'];
    		if ( empty( $image_name )) {
    			$error = 'Please select your photo';
    		} else if( $image_size > 57926 ) {
    			$error = 'Please select your photo less than 1MB';
    		} else {
    			move_uploaded_file($image_tmp_name, $dir.$unique_image);   
    			$error = 'Data upload successfully'; 		
    		}

    		$query = "INSERT INTO 
    				cmbd_users(username,mobile,nid,gender,photo,email,first_name,last_name)
					VALUES('$username','$mobile','$nid','$gender','$photo','$email','$first_name','$last_name')
    		";

    		if ( $db->query($query) ) {
    			$error = 'Insert Data Successfully';
    		} else {
    			$error = 'Please try again';
    		}  
    	}


    	// exit;
    	
    	






    }

  

?>
<!DOCTYPE html> 
<html>
	
<head>
		<title>CODEMANBD 05</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0">
		
		<link rel="stylesheet" href="css/demo.css">
		<link rel="stylesheet" href="css/sky-forms.css">
		<!--[if lt IE 9]>
			<link rel="stylesheet" href="css/sky-forms-ie8.css">
		<![endif]-->
		
		<!--[if lt IE 10]>
			<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
			<script src="js/jquery.placeholder.min.js"></script>
		<![endif]-->		
		<!--[if lt IE 9]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
			<script src="js/sky-forms-ie8.js"></script>
		<![endif]-->
	</head>
	<body class="bg-cyan">
		<div class="body body-s">
		
			<form action="" method="POST" class="sky-form" enctype="multipart/form-data">
				<header>
					<h3>Registration form</h3>
					<?php echo $error ?? ''; ?>
				</header>


				
				<fieldset>					
					<section>
						<label class="input">
							<i class="icon-append icon-user"></i>
							<input type="text" placeholder="Username" name="username" value="<?php echo $_POST['username'] ?? '' ;?>">
							<b class="tooltip tooltip-bottom-right">Only latin characters and numbers</b>
						</label>
					</section>
					
					<section>
						<label class="input">
							<i class="icon-append icon-envelope-alt"></i>
							<input type="text" placeholder="Email address" name="email" value="<?php echo $_POST['email'] ?? '' ;?>">
							<b class="tooltip tooltip-bottom-right">Needed to verify your account</b>
						</label>
					</section>
					
					<section>
						<label class="input">
							<i class="icon-append icon-lock"></i>
							<input type="text" placeholder="Mobile" name="mobile">
							<b class="tooltip tooltip-bottom-right">Only numbers</b>
						</label>
					</section>
					
					<section>
						<label class="input">
							<i class="icon-append icon-lock"></i>
							<input type="text" placeholder="National Id" name="nid">
							<b class="tooltip tooltip-bottom-right">Only latin characters and numbers</b>
						</label>
					</section>
				</fieldset>
					
				<fieldset>
					<div class="row">
						<section class="col col-6">
							<label class="input">
								<input type="text" placeholder="First name" name="first_name">
							</label>
						</section>
						<section class="col col-6">
							<label class="input">
								<input type="text" placeholder="Last name" name="last_name">
							</label>
						</section>
					</div>
					
					<section>
						<label class="select">
							<select name="gender">
								<option value="0" selected disabled>Gender</option>
								<option value="Male">Male</option>
								<option value="Female">Female</option>
								<option value="Other">Other</option>
							</select>
							<i></i>
						</label>
					</section>				
					<!-- <section>
						<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>I agree to the Terms of Service</label>
						<label class="checkbox"><input type="checkbox" name="checkbox"><i></i>I want to receive news and  special offers</label>
					</section> -->
				</fieldset>

				<fieldset>
							<header>Profile Picture</header>
					<section>
						<label class="input">
							<input type="file" name="photo" id="photo">
						</label>
					</section>
				</fieldset>
				<footer>
					<input type="submit" value="Submit" name="registration_form" class="button">
				</footer>
			</form>
			
		</div>
	</body>

</html>