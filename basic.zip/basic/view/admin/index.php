<?php include('componentes/header.php'); ?>
<?php include('componentes/sidebar.php'); ?>
<?php include('content.php'); ?>

<?php include('componentes/footer.php'); ?>