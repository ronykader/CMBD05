
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2018-2019 <a href="">CodemanBD</a>.</strong> All rights
    reserved.
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<script src="../../assets/admin/js/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="../../assets/admin/js/bootstrap.min.js"></script>
<!-- SlimScroll -->
<script src="../../assets/admin/js/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../assets/admin/js/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../assets/admin/js/w3zones.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../assets/admin/js/demo.js"></script>
<script>

  $(document).ready(function () {

    $('.sidebar-menu').tree()
  })




</script>
</body>
</html>