  <section class="main-content-area">
    <div class="container">
      <div class="row">
        <div class="col-12">
          <div class="about-us">
            <h1 class="">Welcome to CodemanBD</h1>
            <p>Newport High School (NHS) is a public secondary school in Bellevue, Washington. It serves students in grades 9–12 in the southern part of the Bellevue School District, including the neighborhoods of Eastgate, Factoria, Newport Hills, Newport Shores, Somerset, The Summit, and Sunset. As of the 2014-2015 school year, the principal is Dion Yahoudy. The mascot is the Knight... <a href="#">Readmore</a></p>
          </div>
        </div>
      </div>
    </div>
  </section><!-- End main content slide -->