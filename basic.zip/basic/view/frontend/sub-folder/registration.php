<section class="main-content-area">
  <div class="container">
    <div class="row">
      <div class="col-12">
        <div class="about-us">
          <h1 class="">User Registration Panel</h1>

            <div class="container maincontainer">
               <form class="form-group " action="" method="POST"  enctype="multipart/form-data">

                   <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="firstname" class="label2 ">First Name</label>
                   </div>

                    <div class="col-md-6 col-sm-6 col-xs-12">
                       <div class="form-group">
                            <input id="firstname" type="text" name="firstname" value="<?php echo  $_POST['firstname'] ?? ""; ?>"  class="input1 form-control">
                        </div>
                   </div>
                   <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="lastname" class="label2 ">Last Name</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                       <div class="form-group">
                            <input id="lastname" type="text" name="lastname" value="<?php echo  $_POST['lastname'] ?? ""; ?>"  class="input1 form-control">
                        </div>
                   </div>
                   <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="usertype" class="label2 ">User Type</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <select class="form-control input1" name="usertype" value=" ">
                                <option>admin</option>
                                <option>user</option>
                            </select>
                        </div>

                   </div>
                    <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="email" class="label2 ">Email</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                       <div class="form-group">
                            <input id="email" type="email" name="email" value="<?php echo  $_POST['email'] ??""; ?>"  class="input1 form-control">
                        </div>
                   </div>
                    <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="phone" class="label2 ">Phone Number</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                       <div class="form-group">
                            <input id="phone" type="text" name="phone" value="<?php echo  $_POST['phone'] ??""; ?>"  class="input1 form-control">
                        </div>
                   </div>
    
                  
                    <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="presentaddress" class="label2 ">Present Address</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <textarea id="presentaddress" rows="2" name="presentaddress" placeholder="<?php echo  $_POST['presentaddress'] ??""; ?>"  class="input1 form-control" ></textarea>
                        </div>
                   </div>
                   
                   <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="permanentaddress" class="label2 ">Permanent Address</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <textarea id="permanentaddress" rows="2" name="permanentaddress" placeholder="<?php echo  $_POST['permanentaddress'] ??""; ?>"  class="input1 form-control" ></textarea>
                        </div>
                   </div>
                   <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="password" class="label2 ">Password</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                       <div class="form-group">
                           <input id="password" type="password" name="password"   class="input1 form-control">
                       </div>
                   </div>
                   
                   <div class="col-md-4 col-sm-4 text-right col-xs-12">
                       <label for="profilepic" class="label2 ">Profile Pic</label>
                   </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="form-group">
                            <input id="profilefile" type="file" name="profilefile" value=""  class="input1 form-control">
                        </div>
                   </div>

                   
                   <div class="col-md-6 col-sm-6 col-xs-12 pull-right">
                        <input  name="submit_re" type="reset" class="btn btn-danger" value="Reset">
                        <input  name="submit_info" type="submit" class="btn btn-info" value="Submit Information">
                   </div>
               </form>       
            </div>
          </p>
        </div>
      </div>     

    </div>
  </div>
</section>
<!-- End main content slide -->
