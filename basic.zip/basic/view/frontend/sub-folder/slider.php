<section class="hero-slide-area">
  <div class="container-fluid">
    <div class="row">
      <div class="col">

        <div id="hero-slide" class="owl-carousel owl-theme">
          <!-- <div class="item">
            <div class="hero-slide">
              <img src="img/slide4.jpg" alt="">
            </div>
          </div> -->
          <!-- <div class="item">
            <div class="hero-slide">
              <img src="img/slide2.jpg" alt="">
            </div>
          </div> -->
          <div class="item">
            <div class="hero-slide">
              <img src="http://localhost/ju.datacollection/public/frontend_assets/img/slide3.jpg" alt="">
            </div>
          </div>
          <!--
          <div class="item">
            <div class="hero-slide">
              <img src="img/slide4.jpg" alt="">
            </div>
          </div> -->
      </div>
      </div>
    </div>
  </div>
</section>
<!-- End hero slide -->