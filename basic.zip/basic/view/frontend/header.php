<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="manifest" href="site.webmanifest">
  <link rel="apple-touch-icon" href="icon.png">
  <!-- Place favicon.ico in the root directory -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="../../assets/frontend/css/normalize.css">
  <link rel="stylesheet" href="../../assets/frontend/css/plugins.css">
  <link rel="stylesheet" href="../../assets/frontend/css/main.css">
  
</head>

<body>
  <!--[if lte IE 9]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->


<nav class="navbar navbar-expand-md custom-menu">
  <div class="container">
    <a class="navbar-brand" href="#">
      <h2>CodemanBD</h2>
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span>
    </button>
    <div class="collapse navbar-collapse flex-row-reverse" id="collapsibleNavbar">
      <ul class="navbar-nav">  
           
                  <li class="nav-item">
            <a class="nav-link" href="http://localhost/ju.datacollection/admin/login">Administration</a>
          </li>
            <li class="nav-item">
                <a class="nav-link" href="http://localhost/ju.datacollection/login">Login</a>
            </li>
         
      </ul>
    </div> 
    </div> 
</nav>