<!-- HEADER AREA -->
<?php include('header.php'); ?>

<!-- SLIDER AREA -->
<?php include('sub-folder/slider.php'); ?>

<!-- MAIN CONTENT AREA -->
	
<?php 
	$registration = 1;

	if ( $registration ) {
		include('sub-folder/registration.php');
	} else {
		include('sub-folder/content.php');

		$r = 'ddkdk';

		define('HOST','localhost');

		echo HOST;
	}

?>



<!-- FOOTER AREA -->
<?php include('footer.php'); ?>
