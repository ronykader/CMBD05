

<section class="footer-area">
  <div class="container">
    <div class="row">
        <div class="col-4 ft-one">
          <div class="footer-item ">
            <ul class="list-unstyled">
              <li>Jahangirnagar University, Savar, Dhaka-1342, Bangladesh. <i class="fa fa-map-marker"></i></li>
              <li>880-2-7791045-51 <i class="fa fa-phone"></i></li>
              <li>880-2-7791052 <i class="fa fa-fax"></i></li>
              <li>webs@juniv.edu <i class="fa fa-envelope"></i></li>
            </ul>
          </div>
        </div>
        <div class="col-4 footer-two">
            <div class="footer-item">
                <div class="footer-socials">
                  <ul class="list-unstyled">
                    <li><a href=""><i class="fa fa-facebook"></i></a></li>
                    <li><a href=""><i class="fa fa-twitter"></i></a></li>
                    <li><a href=""><i class="fa fa-youtube"></i></a></li>
                    <li><a href=""><i class="fa fa-twitter"></i></a></li>
                    <li><a href=""><i class="fa fa-google-plus"></i></a></li>
                    <li><a href=""><i class="fa fa-linkedin"></i></a></li>
                  </ul>
                </div>
          </div>
        </div>
        <div class="col-4 fi-three">
            <div class="footer-item ">
            <ul class="list-unstyled">
              <li><a href="">Registered Graduates List</a></li>
              <li><a href="">Faculty Members</a></li>
              <li><a href="">ICT Cell</a></li>
              <li><a href="">Notice</a></li>
            </ul>
            </div>
        </div>
    </div>
  </div>
</section>




  <script src="../../assets/frontend/js/modernizr-3.6.0.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=" crossorigin="anonymous"></script>
  <script>window.jQuery || document.write('<script src="js/vendor/jquery-3.3.1.min.js"><\/script>')</script>
  <script src="../../assets/frontend/js/plugins.js"></script>

  <script src="../../assets/frontend/js/main.js"></script>


</body>

</html>