
/* ----------------------
#HERO SLIDE ACTIVATION
----------------------- */
$('#hero-slide').owlCarousel({
    loop:true,
    nav:true,
    dots: false,
    autoplayHoverPause: true,
    autoplay: true,
    autoplaySpeed: 4000,
    autoplayTimeout: 4000,
    navSpeed:4000,
    items:1
})