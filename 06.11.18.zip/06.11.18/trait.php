<?php

/**
 * The Template for displaying product archives, including the main shop page which is a post type archive.
 *
 * Override this template by copying it to yourtheme/woocommerce/archive-product.php
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     3.4.0
 */

if (!defined('ABSPATH')) exit; // Exit if accessed directly

get_header('shop'); ?>




<div class="container">
	<div class="page-content sidebar-position-<?php echo $position; ?> responsive-sidebar-<?php echo $responsive; ?> sidebar-mobile-position-<?php echo etheme_get_option('sidebar_position_mobile'); ?>">

		<div class="row-fluid">
			<?php if ($position == 'left') : ?>
				<div class="<?php echo $sidebar_span; ?> sidebar sidebar-left">
					<?php do_action('woocommerce_sidebar'); ?>
				</div>
			<?php endif; ?>

			<div class="content <?php echo $content_span; ?>">


					<?php if (woocommerce_product_loop()) : ?>

    					<?php etheme_category_header(); ?>


    					<?php if (etheme_get_option('category_description_position') == "above") {
            do_action('woocommerce_archive_description');
        } ?>

							<div class="toolbar toolbar-top">
								<?php

        /**
         * woocommerce_before_shop_loop hook
         *
         * @hooked woocommerce_result_count - 20
         * @hooked woocommerce_catalog_ordering - 30
         */
        do_action('woocommerce_before_shop_loop');
        ?>
								<div class="clear"></div>
							</div>

						
						<?php echo "<div class='products'>"; ?>

						<?php if (wc_get_loop_prop('total')) { ?>

							<?php while (have_posts()) : the_post(); ?>
								<?php do_action('woocommerce_shop_loop'); ?>
								<?php wc_get_template_part('content', 'product'); ?>

							<?php endwhile; // end of the loop. ?>

						<?php 
    } ?>

							

			<?php woocommerce_product_loop_end(); ?>

				

			<?php endif;?>



			</div>
		</div>

	</div>
</div>
