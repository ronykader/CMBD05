<?php 

    class MysqlConnection {

        public $hostname;
        public $dbuser;
        public $password;
        public $database;

        public function __construct($host,$user,$pass,$db)
        {
            echo $this->hostname = $host."<br>";
            echo $this->dbuser   = $user."<br>";
            echo $this->password = $pass."<br>";
            echo $this->database = $db."<br>";
        }


        public function DatabaseConnection()
        {
            echo "Amader Database connection er jonno lagbe 
                <br>".$this->hostname.'<br>'.$this->dbuser.'<br>'.$this->password.'<br>'.$this->database;
        }


    }

    new MysqlConnection('ag1','ag2','ag3','ag4');



    // function AgainFunction($name = '',$boyos='need to age confirm') {
    //     return "Amar name ".$name." Amar age ".$boyos;
    // }

    // echo AgainFunction('Rayhan');
?>

