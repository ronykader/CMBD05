<?php 

 class Person {

     private $test      = 'This is a Private property';
     protected $test2   = 'This is a Protected property';
     public $name       = 'Md.Tarikul Islam';
     public $address    = 'Dhaka Bangladesh';

    public function __construct() {
        
        echo "aita testing";

    }




     public function CreatePerson()
     {
         return $this->name."</br>".$this->address . "</br> Private property is " . $this->test ;

     }
 }



 $obj = new Person;
//  echo $obj->test;
 echo $obj->CreatePerson();


// class Child extends Person {

//     public function test2()
//     {
//         return $this->test2;
//     }
// }


// $obj = new Child;
// echo $obj->test2();

