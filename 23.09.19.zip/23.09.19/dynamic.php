<?php

    if( isset($_POST['user_submit']) == 'Register' ) {
            $fullName       = $_POST['full_name'];
            $eamilAddress   = $_POST['email_address'];
            $userName       = $_POST['user_name'];
            $phoneNumber    = $_POST['phone_number'];

            if( !empty($fullName) && !empty($eamilAddress) && !empty($userName) && !empty($phoneNumber)) {
                echo "Mail send koro";
            } else {
                echo "Mail send hobe na";
            }
    }

    





























// $host_name    = 'localhost';
// $db_user      = 'root';
// $db_name      = 'cmbd_05';
// $db_password  = '';


// $connection = new mysqli($host_name, $db_user, $db_password, $db_name);

// if ($connection->connect_error) {
    
//     die("Connection Errror".$connection ->connect_error);
// } 


// Get


?>