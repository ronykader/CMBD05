<?php include('db.php') ;?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User Details</title>
</head>
<body>
    <h2>Md.Tarikul Islam</h2>

    <?php 
        
        $urserId = $_GET['userId'] ?? "";


        $sql = "SELECT * FROM cmbd_users WHERE id = '$urserId'";

        $userData = $db->query($sql);

        // print_r($userData);

        $SingleUser = mysqli_fetch_assoc($userData);

        

    ?>

    <h2>Name :<?php echo $SingleUser['full_name'] ;?></h2>
    <h2>Username :<?php echo $SingleUser['user_name'] ;?></h2>
    <h2>Email Address :<?php echo $SingleUser['email_address'] ;?></h2>
    <h2>Phone Number :<?php echo $SingleUser['phone_number'] ;?></h2>
    <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloribus labore earum similique, praesentium autem assumenda cum quo aliquid illum quidem a, nihil repellat sit aut sunt excepturi placeat quae culpa!
    </p>
</body>
</html>