<?php include('db.php') ;?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>User List</title>
</head>
<body>
    <h2>User List</h2>

    <table>
        <tr>
            <th>Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Action</th>
        </tr>

        <?php 
            $sql = "SELECT * FROM cmbd_users";

            $result = $db->query($sql);

            if ( $result->num_rows > 0 ) {
                while ( $data = mysqli_fetch_assoc($result)) {
                    ?>
                    <tr>
                        <td><?php echo $data['full_name'] ;?></td>
                        <td><?php echo $data['user_name'] ;?></td>
                        <td><?php echo $data['email_address'] ;?></td>
                        <td><a href="user-details.php?userId=<?php echo $data['id'];?>">View Details</a></td>
                    </tr>

                    <?php
                }
            }
        
        ;?>

    </table>
</body>
</html>