<?php 
	$host = 'localhost';
	$user = 'root';
	$pass = '';
	$db   = 'ajax_php';

	$conn = new mysqli($host,$user,$pass,$db);


?>