<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Ajax with php</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
</head>
<body>

	<p id='msg'></p>
	
	<input type="text" name="username" id="username" placeholder="Username">

	<input type="text" name="age" id="age" placeholder="Age">

	<input type="text" name="address" id="address" placeholder="Address">

	<button id="btn">Insert Data</button>



	<script>
		;(function($){

			$("#btn").click(function(){

				var username 	= $("#username").val();				
				var age 		= $("#age").val();
				var address 	= $("#address").val();

				if ( username == '' ) {
					alert('Please enter your username');
					return false;
				} else if ( age == '' ) {
					alert('Please enter your age');
					return false;
				} else if ( address == '' ) {
					alert('Please enter your address');
					return false;
				} else {
					$.ajax({
						url 	: 'process.php',
						type 	: 'POST',
						data 	: {
							name 	: username,
							age 	: age,
							address : address
						},
						success : function(data) {
							// document.getElementById('msg').innerHTML = data;
							$('p').text(data);
							$("#username").val("");
							$("#age").val("");
							$("#address").val("");
						} 
					});
				}

			});

		})(jQuery);
	</script>
</body>
</html>