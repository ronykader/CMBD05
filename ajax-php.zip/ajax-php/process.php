<?php 
	include('config.php');

	$name 		= $_POST['name'];
	$age 		= $_POST['age'];
	$address 	= $_POST['address'];


	$sql = "INSERT INTO test (name,age,address) VALUES ('$name','$age','$address')";

	$insert = mysqli_query($conn,$sql);

	if( $insert ) {
		echo "Data insert successfully";
	} else {
		echo "Please try again";
	}



?>