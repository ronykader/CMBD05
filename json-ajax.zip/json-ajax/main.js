// var objectData = {
//     'name' : "Rony Kader",
//     'age' : 28
// }


// var arrayData = ['red','blue','green'];

// console.log(arrayData[2]);

// var TestJson = [
//     {
//         'name' : "Md.Tarikul Islam",
//         'age'  : 28
//     },
//     {
//         'name' : 'Zahid Johir',
//         'age'  : 22
//     }
// ];

// console.log(TestJson[1].name);


// function AddSomeData() {
//     var HtmlString = "<p>Welcome to BD</p>";
//     document.getElementById('data-area').insertAdjacentHTML('beforeend', HtmlString);
// }


// var btn = document.getElementById('btn');

// btn.addEventListener('click',function(){
//     var HtmlString = "<p>Welcome to BD</p>";
//     document.getElementById('data-area').insertAdjacentHTML('beforeend', HtmlString);
// });

// var ourRequestHandle = new XMLHttpRequest();
// ourRequestHandle.open('GET','https://raw.githubusercontent.com/RonyKader/json/master/jsontest-1.json');

// ourRequestHandle.onload = function() {

//     console.log(ourRequestHandle.responseText);
    
// }

// ourRequestHandle.send();




var btnarea     = document.getElementById('btn');
var DataArea    = document.getElementById('data-area');


var countKM = 0;


btnarea.addEventListener('click',function(){
    
    var variable = new XMLHttpRequest();

    variable.open('GET', 'https://raw.githubusercontent.com/RonyKader/json/master/jsontest-1.json');

    variable.onload = function () {
        var Data = JSON.parse(variable.responseText); 
        runHtml(Data);
    }
    variable.send();
    countKM ++;
    if( countKM == 3 ) {
        btnarea.style = 'display:none';
    }


    function runHtml(km) {
        var StringHtml = '';
        for ( i = 0; i < km.length; i++) {
            StringHtml += '<p>'+km[i].name+'</p>';
        }

        DataArea.insertAdjacentHTML('beforeend',StringHtml);
    }
    

});

    


